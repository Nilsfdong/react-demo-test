import React from 'react'

class Tab extends React.Component {

  render () {
    const {item,switchTab}=this.props;
    return(
      <div className="tab-item" onClick={(e)=>switchTab(item)}>{item.value}</div>
    )
  }
}

export default Tab;