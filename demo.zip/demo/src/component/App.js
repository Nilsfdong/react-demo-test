import React from 'react';
import Tab from './Tab';
// import AppList from './AppList.js'
// import AppForm from './AppForm.js'
// import AppFooter from './AppFooter.js'

class App extends React.Component {
  constructor(props){
    super()
    this.state = {
      content: ""
    }
  }
  
  switchTab=(item)=>{
    this.setState({
      content:item.content
    })
  }
  

  renderTab(){
    const content=this.state.content;
    return(
    <div>{content}</div>
    )
  }

  render () {
    const { data } = this.props; 
    return (
      <div>
        <div className="title">React Demo</div>
        <div className='tab'>
          {
            data.map((item)=>{
              console.log(item)
              const id=item.id
              return(
                <Tab item={item}
                     switchTab={this.switchTab}/>
              )
            })
          }
        </div>
        {this.renderTab()}
      </div>
    )
  }
}

export default App;