import React from 'react'
import ReactDOM from 'react-dom'

import App from './component/App'

let data = [{id:0,value:"Tab1",content:"Hello, I am Tab One"},{id:1,value:"Tab2",content:"Hello, I am Tab Two"}]

ReactDOM.render(
  <App data={data}/>,
  document.getElementById('app')
)